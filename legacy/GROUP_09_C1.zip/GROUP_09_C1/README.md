# Group 09 · C1

**Respiratory emergency visits among children under 15**  
Metropolitan Region, 2023–2024  
Ariel Cusacovich and Ana Peris Diaz-Varela  
Business Intelligence · IIB423T-1 · Universidad del Desarrollo  
Version prepared: 28 September 2026 · Submission deadline: 29 September 2026 before 17:50, Santiago time

## Start here

1. Read `report/GROUP_09_C1_Report.pdf`: the self-contained investigation, seven-step map, Five Cs, results, limitations, continuation proposal, Process record and references.
2. Open `presentation/GROUP_09_C1_Slides.pdf` for the defense slides. 
3. Inspect the executed `analysis/C1_respiratory_emergency_visits.ipynb`. Tables, figures and checks are saved inside it.
4. To reproduce the results, follow the instructions below. W1 files are not required.

The PDF is the reviewed report version. No instructor feedback was received after W1.

## Folder structure and file roles

```text
GROUP_09_C1/
  README.md
  report/
    GROUP_09_C1_Report.pdf
  presentation/
    GROUP_09_C1_Slides.pdf
  analysis/
    C1_respiratory_emergency_visits.ipynb
    requirements.txt
  data/
    source/
      AtencionesUrgencia2023.zip
      AtencionesUrgencia2024.zip
      Diccionario_AtencionesUrgencia.xlsx
      sources.csv
    inputs/
      respiratory_RM_2023_raw.csv
      respiratory_RM_2024_raw.csv
    clean/
      respiratory_RM_2023_prepared.csv
      respiratory_RM_2024_prepared.csv
    outputs/
      tables/       18 CSV tables, described below
      figures/      5 PNG figures, described below
```

- `source/` contains unchanged official annual ZIPs, the official dictionary and a provenance register. `sources.csv` describes the real sources; it is not a dataset of visits. Original Spanish field names and official names remain unchanged.
- `inputs/` contains smaller uncleaned extracts: all original 21 fields, after selecting provider region 13, establishment type Hospital and cause codes 1 and 2. These are not samples. Every row of both original CSVs is scanned.
- `clean/` contains the prepared data: the original 21 fields plus `id`, `date`, `year`, `month`, `under_15` and `complete_panel`. Counts and raw rows are retained. IDs are trimmed in the derived field, dates parsed, child counts summed and complete hospitals flagged. Excluded hospitals remain available for sensitivity analysis.
- `outputs/` contains summaries and plots generated from the prepared data. Do not treat these final summaries as the original input.

### Generated tables

| File in data/outputs/tables | Purpose |
|---|---|
| source_checksums.csv | SHA-256 checks for the original analytical files |
| extraction_summary.csv | Rows read and retained from each annual file |
| cause_dictionary.csv | Official meanings of cause codes 1 and 2 |
| variable_profile.csv | Loaded types, null counts and distinct values of all raw fields |
| quality_checks.csv | Validity, keys, age sums, whitespace and recorded-zero checks |
| hospital_names.csv | Hospital IDs and observed annual names |
| coverage.csv | Observed/expected days for each hospital, year and cause, plus panel flag |
| missing_days.csv | Exact absent hospital dates; not imputed |
| before_after_validation.csv | Original and prepared totals for every age/count field by cause |
| annual.csv | Annual respiratory and all-cause volumes, share and daily intensity |
| monthly.csv | Monthly volumes, denominators, share and calendar-adjusted daily average |
| daily.csv | Daily respiratory panel totals |
| daily_summary.csv | Mean, median, quartiles, IQR, standard deviation and observed extremes |
| age_groups.csv | Annual respiratory volume and same-age share for each child age group |
| age_changes.csv | Age-specific changes and contributions to the net decline |
| hospital_annual.csv | Hospital-year volume, denominator, share and daily average |
| hospital_changes.csv | Within-hospital annual changes and official display names |
| sensitivity.csv | Complete panel, all observed hospitals and equal-length-calendar checks |

### Generated figures

`monthly_intensity.png` compares monthly daily averages; `monthly_share.png` compares same-scope respiratory shares; `daily_distribution.png` shows daily variability; `age_groups.png` compares age-specific volumes; `hospital_changes.png` shows hospital contributions to the annual change. The notebook contains the editable code that produces every figure. The PowerPoint contains editable text and a native sensitivity table; analytical charts are embedded images of the notebook figures.

## Reproduce from the original files

Tested with Python 3.12.14, pandas 3.0.1, NumPy 2.5.3, matplotlib 3.11.2, openpyxl 3.1.5, nbformat 5.11.1, nbclient 0.11.0 and ipykernel 7.3.0. The requirements file records the analysis packages and provides JupyterLab as an interface. The interface itself is not needed for the automated execution route.

After extracting the ZIP, open a terminal in `GROUP_09_C1/` and install dependencies in your own Python environment:

```text
python -m pip install -r analysis/requirements.txt
python -m jupyterlab
```

Open the notebook, choose **Restart Kernel and Run All Cells**, and save it. The default workflow reads both original ZIPs, rebuilds the reduced inputs, prepares and reloads the clean files, and regenerates every table and plot. It uses relative paths and works from the project root or `analysis/`. No network connection is required once dependencies are installed. Allow several minutes and sufficient disk space for the archive and generated copies; source CSVs are processed in chunks of 200,000 rows rather than fully expanded in memory.

For automated execution from the project root:

```text
python -c "import nbformat; from nbclient import NotebookClient; p='analysis/C1_respiratory_emergency_visits.ipynb'; n=nbformat.read(p,4); NotebookClient(n,timeout=600,kernel_name='python3').execute(); nbformat.write(n,p)"
```

To start with only the notebook and original sources, retain the two original ZIPs, dictionary and provenance register in `data/source/`. Derived folders are created automatically. Report prose and presentation layout are editorial deliverables; rerunning the notebook regenerates the analytical data, tables and figures, not the Word/PDF or PowerPoint layout. If sources or analysis change, update those documents to match.

For inspection of the prepared CSVs, specify `id` and `IdEstablecimiento` as text, parse `date` as a date and `complete_panel` as boolean, as demonstrated in notebook section 5. Blank relative changes or shares in output tables mean an undefined zero-denominator calculation; they do not mean zero change or zero share.

## Sources and versions

The original snapshots were retrieved and verified on 25 September 2026. Exact URLs, sizes and SHA-256 hashes are in `data/source/sources.csv`. Main official catalogue: <https://datos.gob.cl/dataset/atenciones-de-urgencia>.

- 2023: <https://repositoriodeis.minsal.cl/SistemaAtencionesUrgencia/AtencionesUrgencia2023.zip>
- 2024: <https://repositoriodeis.minsal.cl/SistemaAtencionesUrgencia/AtencionesUrgencia2024.zip>
- Dictionary resource: <https://datos.gob.cl/dataset/atenciones-de-urgencia/resource/79c05b22-391b-4dbd-a362-ba088fecabab>

Keep the included local originals: a public download can be revised. The notebook stops if a source fingerprint differs from the documented version. The dictionary's older establishment annex is not joined. The MINSAL Winter Campaign report dated 10 July 2024 supplies policy context, as cited in the report; it is not used as an analytical table. Classroom files, chats and installed software are not included.

## Verified scope and limitations

The main panel has 22 hospitals and 731 dates. The broad extract has 26 hospitals; four lack a total of 18 hospital-days. Missing records are not imputed. No duplicate deletion, automatic outlier removal or count correction is performed. Preparation preserves all observed count values, and the saved clean files are read back and compared before EDA. Annual, monthly, daily, age and hospital results reconcile.

The notebook has been executed from a fresh kernel, including full source extraction, and saved with outputs. No unresolved analytical execution errors remain. Counts refer to visits at reporting establishments, not distinct patients, residential disease incidence, service quality or a causal intervention effect. Historical observations cannot describe current 2026 operational demand. Future ML and dashboard ideas are proposals, not implemented products.
