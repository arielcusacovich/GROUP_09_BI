# Group 10 W1

**Members:** Ariel Cusacovich and Ana Diaz-Varela  
**Course:** Business Intelligence, IIB423T-1  
**Version date:** 25 September 2026 ·

## Purpose

Compare two research candidates using MINSAL/DEIS emergency visit records for observed hospitals in Chile's Metropolitan Region (RM):

- **A:** monthly respiratory activity among children under 15, during 2023–2024, using a common panel of 22 hospitals with complete daily coverage.
- **B:** distribution of mental disorder visits (F00–F99), ages 15–64, across 26 observed hospitals in 2024.

A is provisionally preferred. The report explains the health context, measurements, limitations and comparison. Counts describe recorded visits, not unique patients or prevalence.

## Reading and execution order

1. Extract `GROUP_10_W1.zip`, retaining the single root folder `GROUP_10_W1` and its internal structure.
2. Read `report/GROUP_10_W1_Report.pdf` for the full investigation, Process record and references.
3. Open `analysis/W1_emergency_visits.ipynb`. It already contains saved tables, figures and execution outputs for inspection without rerunning.
4. To reproduce, install the dependencies below, select the Python kernel, choose **Restart Kernel and Run All Cells**, and save. Run from the project root or from `analysis/`.

The notebook scans the original annual ZIP files in chunks, rebuilds uncleaned extracts, prepares and exports two annual datasets, reloads them, and generates the tables and figures. Derived folders are created automatically. The notebook and files in `data/source/`, together with the installed dependencies, are sufficient to regenerate all data and analytical outputs. No manual extraction of the internal ZIP files or data download is required. Scanning the national datasets may take several minutes.

## Software and dependencies

Verified with Python 3.12.14, pandas 3.0.1, NumPy 2.5.3, matplotlib 3.11.2, openpyxl 3.1.5, ipykernel 7.3.0, nbformat 5.11.1 and nbclient 0.11.0. Versions are listed in `analysis/requirements.txt`.

From a terminal in `GROUP_10_W1`:

```text
python -m venv .venv
.venv\Scripts\activate
python -m pip install -r analysis/requirements.txt
python -m pip install jupyterlab
python -m ipykernel install --user --name group10_w1 --display-name "Python Group 10 W1"
python -m jupyterlab analysis/W1_emergency_visits.ipynb
```

On macOS/Linux, activate the environment with `source .venv/bin/activate`. JupyterLab is the notebook interface; select **Python Group 10 W1**. Internet is needed to install dependencies, but not to run the analysis afterwards. Installed applications and environments are not included in the submission.

## Data organization

**Original sources → uncleaned extracts → prepared datasets → analytical outputs.**

| Folder | Contents | How obtained |
|---|---|---|
| `data/source/` | Original datasets, dictionary and provenance register. | Official files retained unchanged, plus download documentation. |
| `data/inputs/` | Uncleaned extracts for the selected case. | Region, facility-type and cause filters; notebook §2. |
| `data/clean/` | Annual prepared datasets at record level. | Treatment, validation and export; notebook §§4–6.1. |
| `data/outputs/tables/` | Quality checks and analytical tables. | Notebook §§2–9. |
| `data/outputs/figures/` | Three figures used in the report. | Notebook §§7–8. |

The W1 brief requires extracted inputs and processed outputs to be distinguishable within `data/`; these subfolder names are an organizational choice.

## Complete file structure

```text
GROUP_10_W1/
  README.md
  report/
    GROUP_10_W1_Report.pdf
    GROUP_10_W1_Report.docx
  analysis/
    W1_emergency_visits.ipynb
    requirements.txt
  data/
    source/
      AtencionesUrgencia2023.zip
      AtencionesUrgencia2024.zip
      Diccionario_AtencionesUrgencia.xlsx
      sources.csv
    inputs/
      emergency_RM_2023.csv
      emergency_RM_2024.csv
    clean/
      emergency_RM_2023_prepared.csv
      emergency_RM_2024_prepared.csv
    outputs/
      tables/
        extraction_summary.csv
        variable_profile.csv
        quality_checks.csv
        before_after_validation.csv
        coverage.csv
        hospital_coverage.csv
        missing_days.csv
        mental_health_discrepancies.csv
        discrepancy_summary.csv
        panel_annual_totals.csv
        respiratory_annual.csv
        respiratory_monthly.csv
        respiratory_daily_summary.csv
        mental_health_by_hospital.csv
        mental_health_summary.csv
        sensitivity.csv
      figures/
        A_respiratory.png
        A_daily_distribution.png
        B_mental_health.png
```

## Original sources

Both ZIP files are complete national annual datasets published by **MINSAL/DEIS** through the [official emergency visits catalogue](https://datos.gob.cl/dataset/atenciones-de-urgencia). The dictionary provides the asset description, field definitions and annexes. `sources.csv` records exact URLs, retrieval date, file sizes and SHA-256 hashes; it is a provenance register, not a visit dataset.

Official downloads were verified on 25 September 2026. Both annual ZIP hashes match the copies received in the original collection. Keeping these files prevents later portal updates from changing this submission's results. The dictionary metadata was updated in January 2024, but its facility catalogue is dated July 2022; it is not assumed to represent the current network.

Original file contents, source headers, category labels and proper names retain their original Spanish spelling. This preserves provenance and avoids changing input values. Explanations, code comments, derived fields, analytical labels and generated filenames are in English. The report retains official publication titles with English translations for retrieval.

## Uncleaned extracts

`emergency_RM_2023.csv` contains 66,409 rows and `emergency_RM_2024.csv` contains 66,507. Both retain all 21 columns and the values of the selected records. Filters are region 13, facility type Hospital, and causes 1, 2, 36, 38, 39, 40 and 41. The notebook scans 8,899,080 and 8,973,229 original rows, respectively. Only transport format changes: comma-separated UTF-8 replaces semicolon-separated latin1.

For reading the retained source fields:

| Original field | Meaning |
|---|---|
| `IdEstablecimiento` / `NEstablecimiento` | Provider identifier / provider name. |
| `IdCausa` / `GlosaCausa` | SADU cause category key / category description. |
| `Total` | Total visits for that row's cause, facility and date. |
| `Menores_1` | Visits under age 1. |
| `De_1_a_4`, `De_5_a_14`, `De_15_a_64`, `De_65_y_mas` | Visits at ages 1–4, 5–14, 15–64 and 65 or older. |
| `fecha` / `semana` | Visit date / statistical week. |
| `GLOSATIPOESTABLECIMIENTO` | Facility type. |
| `GLOSATIPOATENCION` / `GlosaTipoCampana` | Care type / campaign type labels. |
| `CodigoRegion` / `NombreRegion` | Provider region code / name. |
| `CodigoDependencia` / `NombreDependencia` | Administrative affiliation code / name. |
| `CodigoComuna` / `NombreComuna` | Provider municipality code / name. |

The dictionary does not fully describe the six territorial/affiliation fields. They are not treated as patient residence or as a tested cross-dataset joining key.

## Prepared analytical datasets

`data/clean/emergency_RM_2023_prepared.csv` has 66,409 rows and `data/clean/emergency_RM_2024_prepared.csv` has 66,507. Each has 27 columns and retains all selected records and the 21 original fields. They are not summaries and are not limited to the complete panel: all 26 observed hospitals remain included.

| Added field | Meaning and use |
|---|---|
| `id` | Identifier with leading/trailing whitespace removed; used for grouping. |
| `date` | Standardized date, exported as YYYY-MM-DD. |
| `year` | Year derived from the date. |
| `month` | Calendar month, 1–12. |
| `under_15` | Sum of visits under 1, ages 1–4 and ages 5–14. |
| `panel_A` | True for the 22 hospitals with complete coverage in both years; False for the other four. |

Original `IdEstablecimiento` and `fecha` values remain available for tracing transformations; analysis uses `id` and `date`. Hospital name changes remain in the records, while the latest label is calculated for hospital summaries. The notebook saves both annual files, reloads them, and checks every value for equality before continuing to EDA.

CSV files use commas and UTF-8. Because CSV does not store types, the notebook explicitly reads identifiers as text, parses `date`, and reads `panel_A` as a boolean. Filtering `panel_A == True` reconstructs the panel without storing a duplicate dataset. A and B then apply their respective cause and year filters.

“Prepared” means the documented treatment was applied and verified. It does not mean that missing days or mental disorder detail discrepancies have disappeared. These limitations remain documented; counts are not imputed and unsupported corrections are not made.

## Generated outputs

All table files below are in `data/outputs/tables/`.

| File | Purpose |
|---|---|
| `extraction_summary.csv` | Original and selected row counts by year. |
| `variable_profile.csv` | Types, nulls and distinct values by source column. |
| `quality_checks.csv` | Date, key, count and age-sum checks. |
| `before_after_validation.csv` | Preservation of totals by cause after standardization; the notebook also checks every age group. |
| `coverage.csv` | Observed, expected and missing days by hospital, year and cause. |
| `hospital_coverage.csv` | Hospital coverage and common-panel membership. |
| `missing_days.csv` | Absent dates by hospital and year. |
| `mental_health_discrepancies.csv` | Daily nonzero differences between cause 36 and the sum of 38–41, ages 15–64. |
| `discrepancy_summary.csv` | Number, sign and magnitude of those differences in 2024. |
| `panel_annual_totals.csv` | Totals by cause and year for the 22 complete hospitals. |
| `respiratory_annual.csv` | Respiratory counts and the all-cause denominator under age 15. |
| `respiratory_monthly.csv` | Monthly sums and mean visits per calendar day across the panel. |
| `respiratory_daily_summary.csv` | Mean, median, dispersion and extremes of daily totals. |
| `mental_health_by_hospital.csv` | Counts, shares and reported days by hospital in 2024. |
| `mental_health_summary.csv` | Distribution and concentration across 26 hospitals. |
| `sensitivity.csv` | Annual change with 26 observed hospitals versus 22 complete hospitals. |

Figures in `data/outputs/figures/` are also embedded in the executed notebook and report:

- `A_respiratory.png`: monthly daily averages for 2023 and 2024.
- `A_daily_distribution.png`: histogram of daily respiratory totals in both years.
- `B_mental_health.png`: five hospitals with the highest mental disorder volume in 2024.

## Treatment and interpretation limits

Identifier whitespace is standardized and dates are converted in a copy. Row counts and totals are preserved. High values are not removed and missing days are not imputed. Causes are aggregate categories: components and totals must not be added as if they were separate visits.

There are 18 missing hospital-days across four hospitals. A uses 22 complete hospitals; B retains all 26 observed hospitals with reported-day indicators. In 2024, 1,750 hospital-days have discrepancies between cause 36 and detail categories 38–41; the published total is retained. Horwitz's specialization affects B's distribution and sensitivity. Volume is not interpreted as territorial risk, overcrowding or performance. Joins, ML and dashboards are future proposals, not W1 implementations.

MINSAL technical documents and course references are identified by title, date and location in the report. Copies of classes, conversations, environments and temporary working files are excluded. AI use and verification are documented in the Process record.
